from flask import Flask,render_template

app = Flask(__name__)

@app.route('/')

def fun():
    import datetime
    import os
    from tkinter import messagebox


    date = str(datetime.datetime.now().strftime('%d'))

    with open('List/Date.txt', 'r') as f:
        date_on_file = f.read()

    date_on_file = str(date_on_file)
    name_of_today_file = (datetime.datetime.now().strftime('%D') + str('.csv')).replace('/', '-')

    with open('List/Current_user_list.csv', 'r') as f:
        content = f.readlines()
        # content.remove(",\n")

        Number_of_user = len(content) - 1

    if date != date_on_file:
        with open('List/Absent.txt', 'r') as f:
            content = f.read()

        content = content.split(',')

        with open('List/Present.txt', 'r') as f:
            content2 = f.read()

        content2 = content2.split(',')
        Log_Files = os.listdir('Log')
        Number_of_user_present = 0
        Number_of_user_absent = 0
        if name_of_today_file not in Log_Files:
            pass

        else:
            with open(f'Log/{name_of_today_file}', 'r') as f:
                Number_of_user_present = len(f.readlines()) - 1
                Number_of_user_absent = Number_of_user - Number_of_user_present

        content.append(str(Number_of_user_absent))
        content2.append(str(Number_of_user_present))

        content = str(content)
        content = content.replace('[', '')
        content = content.replace(']', '')
        content = content.replace("'", '')
        content = content.replace(' ', '')

        content2 = str(content2)
        content2 = content2.replace('[', '')
        content2 = content2.replace(']', '')
        content2 = content2.replace("'", '')
        content2 = content2.replace(' ', '')

        with open('List/Absent.txt', 'w') as f:
            f.write(content)

        with open('List/Present.txt', 'w') as f:
            f.write(content2)

        with open('List/Date.txt', 'w') as f:
            f.write(date)

    if date == date_on_file:
        with open('List/Absent.txt', 'r') as f:
            content = f.read()

        content = content.split(',')

        with open('List/Present.txt', 'r') as f:
            content2 = f.read()

        content2 = content2.split(',')

        Log_Files = os.listdir('Log')
        Number_of_user_present = 0
        Number_of_user_absent = 0
        if name_of_today_file not in Log_Files:
            pass
        else:
            with open(f'Log/{name_of_today_file}', 'r') as f:
                Number_of_user_present = len(f.readlines()) - 1

            Number_of_user_absent = Number_of_user - Number_of_user_present

        content[len(content) - 1] = str(Number_of_user_absent)
        content2[len(content) - 1] = str(Number_of_user_present)

        content = str(content)

        content = content.replace('[', '')
        content = content.replace(']', '')
        content = content.replace("'", '')
        content = content.replace(' ', '')

        content2 = str(content2)
        content2 = content2.replace('[', '')
        content2 = content2.replace(']', '')
        content2 = content2.replace("'", '')
        content2 = content2.replace(' ', '')

        with open('List/Absent.txt', 'w') as f:
            f.write(content)

        with open('List/Present.txt', 'w') as f:
            f.write(content2)

    import os
    import datetime

    Name_Of_File = str(datetime.datetime.now().strftime('%D')).replace('/', '-') + str('.csv')
    time = str(datetime.datetime.now().strftime('%D'))

    with open('List/Date2.txt', 'r') as f:
        y = f.read()

    Time_date = str(y)

    if Name_Of_File not in os.listdir('Log'):
        pass
    elif Time_date != time:
        with open(f'Log/{Name_Of_File}', 'r') as f:
            content = f.readlines()[1:]

        Present_Today = []
        for n in content:
            Present_Today.append(n.split(',')[0])

        with open('List/Indivisual_Attandance_Rate.csv', 'r') as f:
            content2 = f.readlines()[1:]
            All_IAR_Date = {}

        for d in content2:
            All_IAR_Date[d.split(',')[0]] = [d.split(',')[1], d.split(',')[2]]

        for x in list(All_IAR_Date.keys()):

            if x in Present_Today:
                print('Hello')
                All_IAR_Date.update({x: [str(int(All_IAR_Date[x][0]) + 1), All_IAR_Date[x][1]]})
            else:
                All_IAR_Date.update({x: [All_IAR_Date[x][0], str(int(All_IAR_Date[x][1]) + 1)]})

        All_IAR_Date = dict(All_IAR_Date)

        for i in All_IAR_Date:
            All_IAR_Date[i.split(',')[0]] = str(All_IAR_Date[i]).replace(',', ":").replace('\\n', '')

        All_IAR_Date = str(All_IAR_Date)
        All_IAR_Date = All_IAR_Date.replace('{', '')
        All_IAR_Date = All_IAR_Date.replace('}', '')
        All_IAR_Date = All_IAR_Date.replace('[', '')
        All_IAR_Date = All_IAR_Date.replace(']', '')
        All_IAR_Date = All_IAR_Date.replace(',', '\n')
        All_IAR_Date = All_IAR_Date.replace('"', '')
        All_IAR_Date = All_IAR_Date.replace("'", '')
        All_IAR_Date = All_IAR_Date.replace(":", ',')
        All_IAR_Date = All_IAR_Date.replace(" ", '')

        with open('List/Date2.txt', 'w') as f:
            f.write(Time_date)
        print(All_IAR_Date)

        with open('List/Indivisual_Attandance_Rate.csv', 'w') as f:
            f.write(f"Name,Absent,Present\n{All_IAR_Date}")


    else:
        pass

    return render_template('Home_Page.html')



if __name__ == '__main__':
    app.run(debug=True,port=5003)