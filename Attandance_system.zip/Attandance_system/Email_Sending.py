from flask import Flask,render_template

app = Flask(__name__)

@app.route('/')

def fun():
    import os
    from email.message import EmailMessage
    import ssl
    import smtplib
    from tkinter import messagebox
    import datetime

    def Email_Sending(Emails):
        for i in range(len(Emails)):
            receiver = Emails[i]
            sender = 'projectexampleemail@gmail.com'
            password = str(os.environ.get('Email_python'))
            subject = 'Absent Today'
            content = '''
            Your ward was absent today.............'''

            em = EmailMessage()
            em['From'] = sender
            em['To'] = receiver
            em['Subject'] = subject
            em.set_content(content)

            context = ssl.create_default_context()

            with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
                smtp.login(sender, password)
                smtp.sendmail(sender, receiver, em.as_string())

    name_of_the_file = str(datetime.datetime.now().strftime('%D')).replace('/', '-') + str('.csv')

    if name_of_the_file not in os.listdir('Log'):
        pass
    else:
        with open('List/Current_user_list.csv', 'r') as f:
            content2 = f.readlines()[1:]
            # content2.remove(',\n')

        All_Users = []
        for n in content2:
            All_Users.append(n.split(',')[0])
        with open(f'Log/{name_of_the_file}', 'r') as f:
            content3 = f.readlines()[1:]

        User_Present_Today = []

        for n2 in content3:
            User_Present_Today.append(n2.split(',')[0])

        User_Absent_today = []

        for n3 in All_Users:
            if n3 not in User_Present_Today:
                User_Absent_today.append(n3)

        with open('List/Email.csv', 'r') as f:
            content4 = f.readlines()[1:]

        All_Email_Data = {}

        for i in content4:
            All_Email_Data[i.split(',')[0]] = i.split(',')[1]

        All_Email_User = []
        for n4 in content4:
            All_Email_User.append(n4.split(',')[0])

        Absent_Email_Registered_Users = []

        for a in User_Absent_today:
            if a in All_Email_User:
                Absent_Email_Registered_Users.append(a)

        Emails = []

        for ab in Absent_Email_Registered_Users:
            val = All_Email_Data[ab]
            Emails.append(val)


        Email_Sending(Emails)



        return render_template('Home_Page.html')



if __name__ == '__main__':
    app.run(debug=True,port=5007)