import face_recognition
import os
import keyboard
import numpy as np
import cv2
from datetime import datetime

All_Encodings = []

name = 0
for x in os.listdir('Images'):
    Current_Image = face_recognition.load_image_file(f"Images/{x}")
    Current_Image = cv2.cvtColor(Current_Image, cv2.COLOR_BGR2RGB)
    Encodings = face_recognition.face_encodings(Current_Image)[0]
    All_Encodings.append(Encodings)

capture = cv2.VideoCapture(0)


def MarkAttandance(Name):
    now = datetime.now()
    Name_of_file = now.strftime("%D")
    Name_of_file = Name_of_file.replace("/", '-')
    time = str(now.strftime("%H-%M-%S"))
    if Name_of_file + str(".csv") not in os.listdir():
        f = open(f"{Name_of_file}.csv", "w")
        f.writelines(f'Name,Time')
        f.close()
    MyNameList = []
    with open(f'{Name_of_file}.csv', 'r+') as f:
        MyDataList = f.readlines()
        for line in MyDataList:
            Entry = line.split(',')
            MyNameList.append(Entry[0])

        if Name not in MyNameList:
            # print(MyNameList)
            f.writelines(f'\n{Name},{time}')
        else:
            return False


while True:
    success, webcam_image_real = capture.read()
    if cv2.waitKey(1) & 0xFF == ord('q'):  # press q to capture
        capture.release()
        cv2.destroyAllWindows()

    # cv2.resize(webcam_image,(0,0),None,0.2,0.2)
    webcam_image = cv2.cvtColor(webcam_image_real, cv2.COLOR_BGR2RGB)
    facesCurFrames = face_recognition.face_locations(webcam_image)
    encodingcurFrames = face_recognition.face_encodings(webcam_image, facesCurFrames)

    for encodeFace, faceLoc in zip(encodingcurFrames, facesCurFrames):
        Distance = face_recognition.face_distance(All_Encodings, encodeFace)
        Suspect = np.argmin(Distance)
        Value = face_recognition.compare_faces([All_Encodings[Suspect]], encodeFace)

        if Value[0] == True:
            print(os.listdir('Images/')[Suspect])
            name = os.listdir('Images/')[Suspect]
            name = name.split('.')
            name = name[0]
            MarkAttandance(name)

        else:
            print("Unknown")
            name = "Unknown"
        try:
            y1, x2, y2, x1 = faceLoc
            cv2.rectangle(webcam_image_real, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(webcam_image_real, name, (x1 + 6, y2 + 20), cv2.FONT_HERSHEY_COMPLEX, 0.7, (0, 255, 0), 2)
            cv2.imshow("Image", webcam_image_real)
            cv2.waitKey(1)


        except Exception as error:
            pass