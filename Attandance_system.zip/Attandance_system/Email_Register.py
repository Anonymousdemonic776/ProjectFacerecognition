from flask import Flask,render_template

app = Flask(__name__)

@app.route('/')

def fun():
    import tkinter as tk
    from tkinter import ttk, messagebox

    root = tk.Tk()
    root.geometry('300x300')
    with open('List/Current_user_list.csv', 'r') as f:
        content = f.readlines()[1:]
        # content.remove(',\n')


    with open('List/Email.csv', 'r') as f:
        content2 = f.readlines()[1:]

    Email_Regsitered_User = []
    All_File = {}

    for n in content2:
        All_File[n.split(',')[0]] = n.split(',')[1]
        Email_Regsitered_User.append(n.split(',')[0])

    User_Names = []

    for names in content:
        namesx = names.split(',')[0]
        namesx = namesx.replace(' ', '')
        User_Names.append(namesx)

    def dict_str(d):
        d2 = str(d)
        d2 = d2.replace('{', '')
        d2 = d2.replace('}', '')
        d2 = d2.replace("'", '')
        d2 = d2.replace(' ', '')
        d2 = d2.replace(',', '\n')
        d2 = d2.replace(':', ',')
        return d2

    def fun():
        val = cmb.get()
        Email = str(User_Emial.get())
        correct = True
        if '@gmail.com' not in Email:
            messagebox.showinfo('Info', f'Email:{Email}\nIs not an correct email address')
            correct = False
            return 0

        val = str(val)
        ans = 'yes'
        if val in Email_Regsitered_User:
            ans = messagebox.askquestion("Info", 'Email Already Registered Do you want to replace it?')
            ans = str(ans.lower())

        if ans == 'yes' and correct == True:
            All_File[val] = Email
            New_content = dict_str(All_File)
            with open('List/Email.csv', 'w') as f:
                f.write(f'''Name,Email\n{New_content}''')

    cmb = ttk.Combobox(root, values=User_Names)
    User_Emial = tk.StringVar()
    Entry = tk.Entry(root, textvariable=User_Emial)
    cmb['state'] = 'readonly'
    btn = tk.Button(root, text='->', command=fun)
    def Delete():
        root2 = tk.Tk()
        root2.geometry('220x220')
        def More():
            value  = cmb2.get()
            Email_Data = {}
            Email_Regsitered_User = []
            for x in content:
                Email_Data[x.split(',')[0]] = x.split(',')[1]
                Email_Regsitered_User.append(x.split(',')[0])

            if value not in Email_Regsitered_User:
                pass
            else:
                Email_Data.pop(value)
                content2 = dict_str(Email_Data)
                with open('List/Email.csv', 'w') as f:
                    f.write(f'''Name,Email\n{content2}''')
                    messagebox.showinfo('Info',f'{value}\'s email deleted')

        with open('List/Email.csv' , 'r') as f:
            content3 = f.readlines()[1:]

        Email_Names = []
        for y in content3:
            Email_Names.append(y.split(',')[0])

        cmb2 = ttk.Combobox(root2,values=Email_Names)
        cmb2.current(0)
        cmb2['state'] = 'readonly'
        btn3 = tk.Button(root2,text='->',command=More)
        cmb2.pack()
        btn3.pack()
        root2.mainloop()

    btn2 = tk.Button(root,text='Delete Email',command=Delete)
    cmb.current(0)
    cmb.pack()
    Entry.pack()
    btn.pack()
    btn2.pack()
    root.mainloop()


    return render_template('Home_Page.html')


if __name__ == '__main__':
    app.run(debug=True,port=5006)