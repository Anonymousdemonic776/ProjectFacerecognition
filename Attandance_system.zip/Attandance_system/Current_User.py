from flask import Flask,render_template


app = Flask(__name__)

@app.route('/')

def fun():
    import os
    os.startfile('C:\\Users\\LENOVO\\Documents\\Attandance_system\\List\\Current_user_list.csv')
    return render_template('Home_Page.html')

if __name__ == '__main__':
    app.run(debug=True,port=5005)