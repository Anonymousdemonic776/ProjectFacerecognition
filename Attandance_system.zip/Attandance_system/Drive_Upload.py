import os

x = os.listdir('List')
