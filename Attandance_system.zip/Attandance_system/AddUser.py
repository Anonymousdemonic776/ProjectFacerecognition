from flask import Flask,render_template
import os

app = Flask(__name__)

@app.route('/')
def fun():
    import cv2
    import tkinter as tk
    from tkinter import messagebox
    from datetime import datetime
    import os
    from functools import partial
    import face_recognition

    root = tk.Tk()
    root.geometry("220x220")
    root.title('Add User')

    def FurtherProcessing(Name):
        Name1 = Name.get()

        Name1 = str(Name1)
        print(Name1)
        List_Of_User = os.listdir("../Attandance_system/Images")
        if Name1 + str(".jpg") in List_Of_User:
            messagebox.showinfo("Info", "User Already exists")
        else:

            vid = cv2.VideoCapture(0)
            root.destroy()

            while True:

                success, img = vid.read()

                cv2.imshow("Image", img)

                if cv2.waitKey(1) & 0xFF == ord('q'):  # press q to capture
                    cv2.imwrite(f"Images/{Name1}.jpg", img)
                    img_user = face_recognition.load_image_file(f'Images/{Name1}.jpg')
                    img_user = cv2.cvtColor(img_user,cv2.COLOR_BGR2RGB)
                    encodings = face_recognition.face_encodings(img_user)
                    print(encodings,len(encodings))
                    if len(encodings) > 1:
                        os.remove(f'Images/{Name1}.jpg')
                        messagebox.showinfo('Info','Multiple Face Detected')
                    else:
                        messagebox.showinfo("info", f"{Name1} successfully added")
                    break


            vid.release()
            cv2.destroyAllWindows()
            now = datetime.now()
            date = now.strftime("%D")
            date = date.replace("/", '-')

            with open('List/Current_user_list.csv','r') as file:
                Content = file.readlines()
                All_Names = []
                for Name in Content:
                    Name = Name.split(',')
                    All_Names.append(Name[0])

            with open('List/Current_user_list.csv' , 'a') as file:

                if Name1 not in All_Names:
                  file.writelines(f'{Name1},{date}\n')
                  file.close()
                else:
                  pass

            # with open('List/Current_Number_of_user.txt' , 'r') as f:
            #     content = f.read()
            #     content = int(content)+1
            #     content  = str(content)
            # with open('List/Current_Number_of_user.txt') as f:
            #     f.write(content)

            with open('List/Indivisual_Attandance_Rate.csv' , 'r') as f:
                content  = f.readlines()
                content.append(f'{Name1},0,0')
                content2 = []
                for n in content:
                    content2.append(n.replace(',',':'))

                content2 = str(content2)
                content2 = content2.replace('[','')
                content2 = content2.replace(']','')
                content2 = content2.replace("'",'')
                content2 = content2.replace(',','\n')
                content2 = content2.replace(' ','')
                content2 = content2.replace(':',',')

            with open('List/Indivisual_Attandance_Rate.csv' , 'w') as f:
                f.write(content2)

    Name = tk.StringVar()

    label1 = tk.Label(root, text="User Name:").pack()

    entry1 = tk.Entry(root, textvariable=Name).pack()
    FurtherProcessing = partial(FurtherProcessing, Name)
    bt1 = tk.Button(root, text="->", command=FurtherProcessing).pack()

    root.mainloop()

    # Name = input()
    #
    # vid = cv2.VideoCapture(0)
    #
    # while True:
    #     success , img = vid.read()
    #
    #     cv2.imshow("Image",img)
    #
    #     if cv2.waitKey(1) & 0xFF == ord('q'): # press q to capture
    #         break
    #
    #
    # cv2.imwrite(f"Images/{Name}.jpg",img)
    #
    # vid.release()
    # cv2.destroyAllWindows()

    return render_template('Home_Page.html')


if __name__ == '__main__':
    app.run(debug=True)