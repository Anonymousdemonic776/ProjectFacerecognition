# # # # # # # # # # import face_recognition
# # # # # # # # # # import os
# # # # # # # # # # import  numpy as np
# # # # # # # # # # import cv2
# # # # # # # # # # from datetime import datetime
# # # # # # # # # #
# # # # # # # # # # now=  datetime.now()
# # # # # # # # # # # print(now.strftime("%H,%M,%S"))
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # # # def MarkAttandance(Name):
# # # # # # # # # # #     now = datetime.now()
# # # # # # # # # # #     Name_of_file = now.strftime("%D")
# # # # # # # # # # #     Name_of_file = Name_of_file.replace("/",'-')
# # # # # # # # # # #     time = str(now.strftime("%H-%M-%S"))
# # # # # # # # # # #     if Name_of_file+str(".csv") not in os.listdir():
# # # # # # # # # # #         f = open(f"{Name_of_file}.csv","w")
# # # # # # # # # # #         f.close()
# # # # # # # # # # #
# # # # # # # # # # #     with open(f'{Name_of_file}.csv',"r+") as Attandnce_file:
# # # # # # # # # # #         Content = Attandnce_file.readline()
# # # # # # # # # # #         print(Content)
# # # # # # # # # # #         Names = []
# # # # # # # # # # #         for line in Content:
# # # # # # # # # # #             line = line.split(',')
# # # # # # # # # # #             line = line[0]
# # # # # # # # # # #             Names.append(line)
# # # # # # # # # # #
# # # # # # # # # # #
# # # # # # # # # # #         if Name not in Names:
# # # # # # # # # # #             with open(f"{Name_of_file}.csv",'a') as Attandance2:
# # # # # # # # # # #                 Attandance2.writelines("Name,Time")
# # # # # # # # # # #                 Attandance2.writelines(f'\n{Name},{time}')
# # # # # # # # # # #         else:
# # # # # # # # # # #             return False
# # # # # # # # # # #
# # # # # # # # # # #     Attandnce_file.close()
# # # # # # # # # # #
# # # # # # # # # # # MarkAttandance("Hey")
# # # # # # # # # #
# # # # # # # # # #
# # # # # # # # # # # ImageSung_jin_woo = face_recognition.load_image_file('Images/Bill_gates.jpg')
# # # # # # # # # # # ImageSung_jin_woo = cv2.cvtColor(ImageSung_jin_woo,cv2.COLOR_BGR2RGB)
# # # # # # # # # # # ImageSung_jin_woo = cv2.resize(ImageSung_jin_woo,None,fx=2,fy=2)
# # # # # # # # # # # Face_Location = face_recognition.face_locations(ImageSung_jin_woo)
# # # # # # # # # # # y1,x2,y2,x1 = Face_Location[0]
# # # # # # # # # # #
# # # # # # # # # # # Face_Encoding = face_recognition.face_encodings(ImageSung_jin_woo)
# # # # # # # # # # # print(len(Face_Encoding[0]))
# # # # # # # # # # # print(face_recognition.compare_faces([Face_Encoding[0]],Face_Encoding[0]))
# # # # # # # # # # # distance = face_recognition.face_distance([Face_Encoding[0]],Face_Encoding[0])
# # # # # # # # # # # print(distance)
# # # # # # # # # # # Imagex = cv2.imread('Images/Bill_gates.jpg')
# # # # # # # # # # # cv2.rectangle(Imagex,(x1,y1),(x2,y2),(255,0,255),2)
# # # # # # # # # # # cv2.imshow("Sung jin woo badass",ImageSung_jin_woo)
# # # # # # # # # # # cv2.waitKey(0)
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # # from datetime import datetime
# # # # # # # # # #
# # # # # # # # # # now = datetime.now()
# # # # # # # # # # Name_of_file = now.strftime("%D")
# # # # # # # # # # Name_of_file = Name_of_file.replace("/", '-')
# # # # # # # # # with open('List/ex.csv') as f1:
# # # # # # # # #     content_all = f1.read()
# # # # # # # # #     f1.close()
# # # # # # # # # with open('List/ex.csv' , 'r+') as f:
# # # # # # # # #     content = f.readlines()
# # # # # # # # #     for line in content:
# # # # # # # # #         if line.split(',')[0] == 'y':
# # # # # # # # #             thing = line
# # # # # # # # #         else:
# # # # # # # # #             pass
# # # # # # # # #
# # # # # # # # #
# # # # # # # # #     content_all = content_all.replace(thing,'')
# # # # # # # # #     f.close()
# # # # # # # # # with open('List/ex.csv' ,'w') as f:
# # # # # # # # #     f.write(content_all)
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # with open('List/ex.csv' , 'r') as f:
# # # # # # # # #     f = f.read()
# # # # # # # # #     print(f)
# # # # # # # # #
# # # # # # # #
# # # # # # # # import cv2
# # # # # # # # vid = cv2.VideoCapture(0)
# # # # # # # #
# # # # # # # # while True:
# # # # # # # #
# # # # # # # #     success, img = vid.read()
# # # # # # # #
# # # # # # # #     cv2.imshow("Image", img)
# # # # # # # #
# # # # # # # #     if cv2.waitKey(1) & 0xFF == ord('q'):  # press q to capture
# # # # # # # #             break
# # # # # # #
# # # # # # #
# # # # # # #
# # # # # # # import face_recognition
# # # # # # #
# # # # # # # f = face_recognition.load_image_file('')
# # # # # #
# # # # # # from matplotlib import pyplot as plt
# # # # # #
# # # # # # plt.pie([10,40],colors=['r','b'])
# # # # # # plt.show()
# # # # # #
# # # # # # with open('List/Email.csv' , 'w') as f:
# # # # # #     f.write('Name,Email'
# # # # # #
# # # # # #     )
# # # # #
# # # # #
# # # # # with open('List/Current_user_list.csv' , 'w') as f:
# # # # #     f.write('Name,Date of joining')
# # # #
# # # # from matplotlib import pyplot as plt
# # # # #
# # # # # plt.plot([1,4,14,25])
# # # # # plt.show()
# # #
# # file = open('List/Email.csv' , 'w')
# # file.write('''Name,Email
# # d,sunitasinghvns81@gmail.com
# # s,anonymous776.001@gmail.com
# # ''')
# #
# #
# def dict_str(d):
#     d2 = str(d)
#     d2 = d2.replace('{', '')
#     d2 = d2.replace('}', '')
#     d2 = d2.replace("'", '')
#     d2 = d2.replace(' ', '')
#     d2 = d2.replace(',', '\n')
#     d2 = d2.replace(':', ',')
#     return d2
# # d = {'a':10,'b':11}
# # # print(dict_str(d))
# # Name1 = 's'
# #
# # with open('List/Email.csv', 'r') as f:
# #     content = f.readlines()[1:]
# #
# # Email_Data = {}
# # Email_Regsitered_User = []
# # for x in content:
# #     Email_Data[x.split(',')[0]] = x.split(',')[1]
# #     Email_Regsitered_User.append(x.split(',')[0])
# #
# # if Name1 not in Email_Regsitered_User:
# #     pass
# # else:
# #     Email_Data.pop(Name1)
# #     content2 = dict_str(Email_Data)
# #     print(content2)
# #     with open('List/Current_user_list.csv', 'w') as f:
# #         f.write(f'''Name,Email\n{content2}''')
#
#
# # with open('List/Current_user_list.csv','w') as f:
# #     f.write('''Name,Time\n,\n''')
#
#
# # with open('List/Current_user_list.csv','r') as f:
# #     content = f.readlines()
# #     content.remove(',\n')
# #     # content = str(content)
# #
# #     content2 = []
# #     for x in content:
# #         content2.append(x.replace(',',':'))
# #
# #     content2 = str(content2)
# #     content2 = content2.replace(']','')
# #     content2 = content2.replace('[','')
# #     content2 = content2.replace("'",'')
# #     content2 = content2.replace(',','\n')
# #     content2 = content2.replace(' ','')
# #     content2 = content2.replace(':',',')
# #     print(content2)
# #
# # with open('List/Current_user_list.csv' , 'w') as f:
# #     f.write(content2)
#
# with open('List/Indivisual_Attandance_Rate.csv' , 'r') as f:
#     content = f.readlines()[1:]
#
#     content2 = {}
#
#     for n in content:
#       content2[n.split(',')[0]] = [n.split(',')[1],n.split(',')[2]]
#
#     print(content2)
#     content2.pop('s')
#     print(content2)
#     content2 = str(content2)
#     content2 = content2.replace("'",'')
#     content2 = content2.replace('{','')
#     content2 = content2.replace('}','')
#     content2 = content2.replace(":",',')
#     content2 = content2.replace('[','')
#     content2 = content2.replace(']','')
#     print(content2)
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#


from matplotlib import pyplot as plt

plt.pie([0,0])

plt.show()
