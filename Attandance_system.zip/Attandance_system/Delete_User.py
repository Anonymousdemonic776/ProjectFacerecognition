from flask import Flask,render_template
import os

app = Flask(__name__)

@app.route('/')
def fun():
    import cv2
    import tkinter as tk
    from tkinter import messagebox
    import os
    from tkinter import ttk
    from functools import partial


    def dict_str(d):
        d2 = str(d)
        d2 = d2.replace('{', '')
        d2 = d2.replace('}', '')
        d2 = d2.replace("'", '')
        d2 = d2.replace(' ', '')
        d2 = d2.replace(',', '\n')
        d2 = d2.replace(':', ',')
        return d2

    root = tk.Tk()
    root.geometry("220x220")
    root.title('Delete User')

    def FurtherProcessing(Name):
        Name1 = cmb.get()
        Name1 = str(Name1).lower()
        List_Of_User = os.listdir("Images")
        if Name1 + str(".jpg") not in List_Of_User:
            messagebox.showinfo("Info", "User Does not exists")
        else:

            os.remove(f"Images/{Name1}.jpg")
            messagebox.showinfo("info", f"{Name1} successfully deleted")
            with open('List/Current_user_list.csv') as f1:
                content_all = f1.read()
                f1.close()
            with open('List/Current_user_list.csv', 'r+') as f:
                content = f.readlines()
                for line in content:
                    if line.split(',')[0] == Name1:
                        thing = line
                    else:
                        pass

                content_all = content_all.replace(thing, '')
                f.close()
            with open('List/Current_user_list.csv', 'w') as f:
                f.write(content_all)

            with open('List/Indivisual_Attandance_Rate.csv', 'r') as f:
                content10 = f.readlines()[1:]

                content20 = {}

                for n in content10:
                    content20[n.split(',')[0]] = [n.split(',')[1], n.split(',')[2]]

                print(content20)
                content20.pop('s')
                print(content20)
                content2 = str(content20)
                content20 = content20.replace("'", '')
                content20 = content20.replace('{', '')
                content20 = content20.replace('}', '')
                content20 = content20.replace(":", ',')
                content20 = content20.replace('[', '')
                content20 = content20.replace(']', '')
                print(content20)

            with open('List/Indivisual_Attandance_Rate.csv' , 'w') as f:
                f.write(f'Name,Absent,Present\n{content20}')


            with open('List/Email.csv' , 'r') as f:
                content = f.readlines()[1:]

            Email_Data = {}
            Email_Regsitered_User = []
            for x in content:
                Email_Data[x.split(',')[0]] = x.split(',')[1]
                Email_Regsitered_User.append(x.split(',')[0])


            if Name1 not in Email_Regsitered_User:
                pass
            else:
                Email_Data.pop(Name1)
                content2 = dict_str(Email_Data)
                with open('List/Email.csv' , 'w') as f:
                    f.write(f'''Name,Email\n{content2}''')



            # with open('List/Current_Number_of_user.txt' , 'r') as f:
            #     num = f.read()
            #     num = int(num) - 1
            #     num = str(num)
            # with open('List/Current_Number_of_user.txt') as f:
            #   f.write(num)


    Name = tk.StringVar()

    label1 = tk.Label(root, text="User Name:").pack()
    Current_user = []
    with open('List/Current_user_list.csv' , 'r') as f:
        content = f.readlines()[1:]
        print(content)
        # content.remove(',\n')

    for n in content:
        Current_user.append(n.split(',')[0])
    # entry1 = tk.Entry(root, textvariable=Name).pack()
    cmb = ttk.Combobox(root,values=Current_user)
    cmb['state'] = 'readonly'
    cmb.current(0)
    cmb.pack()
    FurtherProcessing = partial(FurtherProcessing, Name)
    bt1 = tk.Button(root, text="->", command=FurtherProcessing).pack()

    root.mainloop()



    # Name = input()
    #
    # vid = cv2.VideoCapture(0)
    #
    # while True:
    #     success , img = vid.read()
    #
    #     cv2.imshow("Image",img)
    #
    #     if cv2.waitKey(1) & 0xFF == ord('q'): # press q to capture
    #         break
    #
    #
    # cv2.imwrite(f"Images/{Name}.jpg",img)
    #
    # vid.release()
    # cv2.destroyAllWindows()
    return render_template('Home_Page.html')


if __name__ == '__main__':
    app.run(debug=True,port=5001)